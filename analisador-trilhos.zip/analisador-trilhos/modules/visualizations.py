import streamlit as st
import plotly.express as px

def mostrar_metricas(df_filtrado):
    """Mostra as métricas principais"""
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total de Trechos", f"{len(df_filtrado):,}")
    
    with col2:
        if 'Nível Crítico' in df_filtrado.columns:
            criticos = len(df_filtrado[df_filtrado['Nível Crítico'] == 'Alta'])
            st.metric("Trechos Críticos", f"{criticos:,}")
        else:
            st.metric("Trechos Críticos", "N/A")
    
    with col3:
        if 'DV Atual' in df_filtrado.columns and not df_filtrado['DV Atual'].isna().all():
            avg_dv = df_filtrado['DV Atual'].mean()
            st.metric("DV Médio", f"{avg_dv:.1f}")
        else:
            st.metric("DV Médio", "N/A")
    
    with col4:
        if 'Restrição Via (Motivo)' in df_filtrado.columns:
            com_restricao = df_filtrado['Restrição Via (Motivo)'].apply(
                lambda x: str(x) not in ['nan', 'None', 'NÃO INFORMADO', '']
            ).sum()
            st.metric("Com Restrição", f"{com_restricao:,}")
        else:
            st.metric("Com Restrição", "N/A")

def criar_grafico_classes(df_filtrado):
    """Cria gráfico de distribuição por classe"""
    if 'Classe' in df_filtrado.columns and len(df_filtrado) > 0:
        df_classe = df_filtrado.copy()
        df_classe['Classe'] = df_classe['Classe'].astype(str)
        df_classe = df_classe[~df_classe['Classe'].isin(['nan', 'None', 'NaN', 'NÃO INFORMADO', ''])]
        
        if len(df_classe) > 0 and df_classe['Classe'].nunique() > 0:
            fig = px.pie(df_classe, names='Classe', title='Distribuição por Classe',
                        color_discrete_sequence=px.colors.qualitative.Set3)
            return fig
    return None

def criar_grafico_criticidade(df_filtrado):
    """Cria gráfico de distribuição por nível crítico"""
    if 'Nível Crítico' in df_filtrado.columns and len(df_filtrado) > 0:
        fig = px.bar(df_filtrado, x='Nível Crítico', 
                    title='Distribuição por Nível Crítico',
                    color='Nível Crítico',
                    color_discrete_map={'Alta': '#DC2626', 'Média': '#F59E0B', 'Baixa': '#10B981'})
        return fig
    return None

def criar_tabela_priorizacao(df_filtrado):
    """Cria tabela de priorização"""
    if len(df_filtrado) > 0:
        col_ordenacao = 'Score Prioridade' if 'Score Prioridade' in df_filtrado.columns else 'DV Atual'
        
        if col_ordenacao in df_filtrado.columns:
            df_priorizado = df_filtrado.sort_values(col_ordenacao, ascending=False).head(50)
        else:
            df_priorizado = df_filtrado.head(50)
        
        colunas_para_exibir = []
        colunas_basicas = ['Equipamento', 'Gerência', 'Classe', 'Nível Crítico']
        
        for col in colunas_basicas:
            if col in df_priorizado.columns:
                colunas_para_exibir.append(col)
        
        if 'DV Atual' in df_priorizado.columns:
            colunas_para_exibir.append('DV Atual')
        if 'Score Prioridade' in df_priorizado.columns:
            colunas_para_exibir.append('Score Prioridade')
        
        return df_priorizado[colunas_para_exibir]
    return pd.DataFrame()