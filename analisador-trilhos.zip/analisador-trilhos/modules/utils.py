import pandas as pd
import numpy as np

def limpar_valor(valor):
    """Limpa e converte valores do DataFrame"""
    if pd.isna(valor):
        return None
    if isinstance(valor, (int, float, np.integer, np.floating)):
        return valor
    if isinstance(valor, str):
        valor = valor.strip()
        try:
            if ',' in valor and '.' not in valor:
                valor = valor.replace(',', '.')
            return float(valor)
        except:
            return valor if valor not in ['', 'nan', 'NaN', 'None', 'null'] else None
    return valor

def criar_lista_filtro(coluna, df, texto_todas="Todas"):
    """Cria lista segura para filtros"""
    try:
        if coluna not in df.columns:
            return [texto_todas]
        
        valores = df[coluna].dropna().astype(str).str.strip().unique()
        valores_validos = [v for v in valores if v not in ['', 'nan', 'NaN', 'None', 'null', 'NÃO INFORMADO']]
        
        if not valores_validos:
            return [texto_todas]
        
        try:
            valores_ordenados = sorted(valores_validos)
        except:
            valores_ordenados = list(valores_validos)
        
        return [texto_todas] + valores_ordenados
    except:
        return [texto_todas]